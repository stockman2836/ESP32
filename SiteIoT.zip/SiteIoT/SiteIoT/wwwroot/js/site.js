﻿function toggleSystem() {
    fetch('/toggle-system', { method: 'POST' })
        .then(response => {
            if (response.ok) {
                return response.json();
            }
            throw new Error('Network response was not ok.');
        })
        .then(data => {
            console.log('System status:', data.status);
        })
        .catch(error => {
            console.error('There has been a problem with your fetch operation:', error);
        });
}

function disableAlarm() {
    fetch('/disable-alarm', { method: 'POST' })
        .then(response => {
            if (response.ok) {
                return response.json();
            }
            throw new Error('Network response was not ok.');
        })
        .then(data => {
            console.log('Alarm status:', data.status);
        })
        .catch(error => {
            console.error('There has been a problem with your fetch operation:', error);
        });
}
