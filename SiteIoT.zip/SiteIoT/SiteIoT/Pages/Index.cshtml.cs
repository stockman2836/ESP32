﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Devices.Client;
using Microsoft.Extensions.Logging;
using System;
using System.Text;
using System.Threading.Tasks;

public class IndexModel : PageModel
{
    private readonly ILogger<IndexModel> _logger;
    private static DeviceClient? deviceClient;
    private static string connectionString = "HostName=AlarmSystemDavydenko.azure-devices.net;DeviceId=esp32projectdavydenko;SharedAccessKey=wlAK6NmBc4fseb7SYEFGIuLZPBRFBhw3HAIoTC9CpaE=";

    public IndexModel(ILogger<IndexModel> logger)
    {
        _logger = logger;
        if (deviceClient == null)
        {
            _logger.LogInformation("Инициализация DeviceClient.");
            deviceClient = DeviceClient.CreateFromConnectionString(connectionString, TransportType.Mqtt);
        }
    }

    public void OnGet()
    {

    }

    public async Task<IActionResult> OnPostToggleSystemAsync()
    {
        if (deviceClient == null)
        {
            _logger.LogError("DeviceClient не инициализирован.");
            return Page();
        };

        var message = new Message(Encoding.UTF8.GetBytes("Toggle system command"));
        _logger.LogInformation("Отправка команды на переключение системы.");
        await deviceClient.SendEventAsync(message);
        _logger.LogInformation("Команда на переключение системы отправлена.");

        return RedirectToPage();
    }

    public async Task<IActionResult> OnPostDisableAlarmAsync()
    {
        if (deviceClient == null)
        {
            _logger.LogError("DeviceClient не инициализирован.");
            return Page();
        }

        var message = new Message(Encoding.UTF8.GetBytes("Disable alarm command"));
        _logger.LogInformation("Отправка команды на отключение сигнализации.");
        await deviceClient.SendEventAsync(message);
        _logger.LogInformation("Команда на отключение сигнализации отправлена.");

        return RedirectToPage();
    }
}
